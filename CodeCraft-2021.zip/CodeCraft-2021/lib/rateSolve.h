#ifndef __rateSolve__
#define __rateSolve__
struct rateSolve{

};
#endif